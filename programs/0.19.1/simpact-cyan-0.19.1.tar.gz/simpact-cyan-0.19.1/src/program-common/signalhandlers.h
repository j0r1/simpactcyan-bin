#ifndef SIGNALHANDLERS_H

#define SIGNALHANDLERS_H

void installSignalHandlers();

#endif // SIGNALHANDLERS_H
