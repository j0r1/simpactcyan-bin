#ifndef SIMPACTPOPULATION_H

#define SIMPACTPOPULATION_H

#include "population.h"
#include <assert.h>

class PopulationDistribution;
class Person;
class Man;
class Woman;

class SimpactPopulationConfig : public errut::ErrorBase
{
public:
	SimpactPopulationConfig();
	~SimpactPopulationConfig();

	void setInitialMen(int number)						{ m_initialMen = number; }
	void setInitialWomen(int number)					{ m_initialWomen = number; }

	int getInitialMen() const						{ return m_initialMen; }
	int getInitialWomen() const						{ return m_initialWomen; }
private:
	int m_initialMen, m_initialWomen;
};

class SimpactPopulation : public Population
{
public:
	SimpactPopulation(bool parallel, GslRandomNumberGenerator *pRng);
	~SimpactPopulation();

	bool init(const SimpactPopulationConfig &popConfig, const PopulationDistribution &popDist);

	Person **getAllPeople()							{ return reinterpret_cast<Person**>(Population::getAllPeople()); }
	Man **getMen()								{ return reinterpret_cast<Man**>(Population::getMen()); }
	Woman **getWomen()							{ return reinterpret_cast<Woman**>(Population::getWomen()); }
protected:
	virtual void onScheduleInitialEvents();
private:
	void onAboutToFire(EventBase *pEvt);

	bool m_init;
};

inline SimpactPopulation &SIMPACTPOPULATION(State *pState)
{
	assert(pState != 0);
	return static_cast<SimpactPopulation &>(*pState);
}

inline const SimpactPopulation &SIMPACTPOPULATION(const State *pState)
{
	assert(pState != 0);
	return static_cast<const SimpactPopulation &>(*pState);
}

#endif // SIMPACTPOPULATION_H

