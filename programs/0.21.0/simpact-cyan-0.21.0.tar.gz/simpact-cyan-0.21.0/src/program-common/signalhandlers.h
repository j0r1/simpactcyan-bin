#ifndef SIGNALHANDLERS_H

#define SIGNALHANDLERS_H

void installSignalHandlers();
void writeUnexpectedTermination();

#endif // SIGNALHANDLERS_H
