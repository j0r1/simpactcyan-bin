#include "booltype.h"

char bool_t::s_defaultErrMsg[] = "Unknown error";
char bool_t::s_defaultSuccessMsg[] = "Success";

