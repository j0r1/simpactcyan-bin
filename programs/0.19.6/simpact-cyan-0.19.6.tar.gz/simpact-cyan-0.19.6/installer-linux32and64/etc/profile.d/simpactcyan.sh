
if [ -z "$PYTHONPATH" ] ; then
	PYTHONPATH=/usr/share/simpact-cyan/python
else
	PYTHONPATH="$PYTHONPATH":/usr/share/simpact-cyan/python
fi

export PYTHONPATH
