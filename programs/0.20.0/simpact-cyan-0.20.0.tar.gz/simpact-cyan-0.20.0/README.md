Simpact Cyan
============

Simpact Cyan is the C++ version of the [Simpact](http://www.simpact.org/) family 
of programs. It is an agent based model (ABM) to study the way an infection 
spreads and can be influenced, and is currently focused on HIV. 

The main documentation can be found at [readthedocs](http://simpactcyan.readthedocs.io/).

Source code packages and pre-compiled versions can be found [here](http://research.edm.uhasselt.be/jori/simpact/programs/).

